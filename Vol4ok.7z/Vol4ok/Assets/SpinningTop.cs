using UnityEngine;

[RequireComponent(typeof(Rigidbody))]
public class RealisticTop : MonoBehaviour
{
    [Header("Физические параметры")]
    public float initialSpin = 100f;     // Начальная угловая скорость
    public float mass = 1f;              // Масса волчка
    public float drag = 0.1f;            // Сопротивление воздуха
    public float groundFriction = 0.5f;  // Трение о поверхность
    
    [Header("Геометрия")]
    public float tipRadius = 0.1f;       // Радиус острия
    public float height = 1f;            // Высота волчка
    
    [Header("Прецессия")]
    public float precessionRate = 2f;    // Скорость прецессии
    public float nutationAngle = 5f;     // Угол нутации

    private Rigidbody rb;
    private bool isGrounded;
    private float currentSpin;

    void Start()
    {
        rb = GetComponent<Rigidbody>();
        ConfigurePhysics();
        Launch(initialSpin);
    }

    void ConfigurePhysics()
    {
        rb.mass = mass;
        rb.linearDamping = drag;
        rb.angularDamping = 0.05f;
        rb.interpolation = RigidbodyInterpolation.Interpolate;
        rb.collisionDetectionMode = CollisionDetectionMode.ContinuousDynamic;
    }

    public void Launch(float spinForce)
    {
        currentSpin = spinForce;
        rb.AddTorque(transform.up * spinForce, ForceMode.Impulse);
    }

    void FixedUpdate()
    {
        CheckGroundContact();
        ApplyPrecession();
        ApplyGroundFriction();
        ApplyGravityEffects();
        CheckStopping();
    }

    void CheckGroundContact()
    {
        isGrounded = Physics.Raycast(transform.position, -Vector3.up, 
                      height * 0.5f + tipRadius);
    }

    void ApplyPrecession()
    {
        if (!isGrounded) return;
        
        // Прецессия (медленное вращение оси)
        float precessionTorque = currentSpin * Mathf.Sin(nutationAngle * Mathf.Deg2Rad) / precessionRate;
        rb.AddTorque(transform.right * precessionTorque * Time.fixedDeltaTime);
        
        // Нутация (колебания оси)
        float nutation = Mathf.Sin(Time.time * precessionRate) * 0.1f;
        rb.AddTorque(transform.forward * nutation * Time.fixedDeltaTime);
    }

    void ApplyGroundFriction()
    {
        if (!isGrounded) return;
        
        // Трение уменьшает скорость вращения
        currentSpin -= groundFriction * Time.fixedDeltaTime;
        rb.angularVelocity *= 0.995f;
    }

    void ApplyGravityEffects()
    {
        if (!isGrounded) return;
        
        // Чем медленнее вращение, тем сильнее наклон
        float tiltFactor = 1 - (currentSpin / initialSpin);
        Vector3 gravityTorque = Vector3.Cross(transform.up, Vector3.up) * tiltFactor * 9.81f;
        rb.AddTorque(gravityTorque * Time.fixedDeltaTime, ForceMode.VelocityChange);
    }

    void CheckStopping()
    {
        if (currentSpin <= 0.1f || transform.up.y < 0.1f)
        {
            rb.angularVelocity = Vector3.zero;
            enabled = false;
        }
    }

    void OnCollisionEnter(Collision collision)
    {
        // При ударе добавляем хаотичное вращение
        foreach (ContactPoint contact in collision.contacts)
        {
            rb.AddTorque(Random.onUnitSphere * collision.impulse.magnitude, 
                        ForceMode.Impulse);
        }
    }
}